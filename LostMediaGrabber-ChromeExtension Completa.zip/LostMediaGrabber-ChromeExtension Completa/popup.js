document.getElementById('searchBtn').addEventListener('click', buscarMultimedia);
document.getElementById('downloadBtn').addEventListener('click', descargarTXT);

let resultadosURLs = [];

async function buscarMultimedia() {
  const domainInput = document.getElementById('domain').value.trim();
  const statusDiv = document.getElementById('status');
  const downloadBtn = document.getElementById('downloadBtn');

  if (!domainInput) {
    statusDiv.textContent = "⚠️ Ingresa un dominio válido.";
    return;
  }

  statusDiv.textContent = `Consultando Wayback API para: ${domainInput}...\n`;
  downloadBtn.style.display = "none";
  resultadosURLs = [];

  const cdxUrl = `https://web.archive.org/cdx/search/cdx?url=${domainInput}/*&filter=mimetype:(image/.*|video/.*)&output=json&fl=timestamp,original&limit=1500`;

  try {
    const response = await fetch(cdxUrl);
    if (!response.ok) throw new Error(`HTTP: ${response.status}`);

    const data = await response.json();

    if (!data || data.length <= 1) {
      statusDiv.textContent += "\n❌ No se encontraron archivos archivados.";
      return;
    }

    const capturas = data.slice(1);
    const setMedios = new Set();
    const extensionesRegex = /\.(jpg|jpeg|png|gif|webp|svg|mp4|webm|mov)(\?.*)?$/i;

    capturas.forEach(([timestamp, originalUrl]) => {
      if (!originalUrl.includes("web.archive.org") && !originalUrl.includes("analytics")) {
        if (extensionesRegex.test(originalUrl)) {
          setMedios.add(`https://web.archive.org/web/${timestamp}/${originalUrl}`);
        }
      }
    });

    resultadosURLs = Array.from(setMedios);

    if (resultadosURLs.length === 0) {
      statusDiv.textContent += "\n❌ Sin archivos multimedia compatibles.";
    } else {
      statusDiv.textContent = `¡ÉXITO!\nSe encontraron ${resultadosURLs.length} archivos multimedia.`;
      downloadBtn.style.display = "block";
    }

  } catch (error) {
    statusDiv.textContent += `\n❌ Error: ${error.message}`;
  }
}

function descargarTXT() {
  if (resultadosURLs.length === 0) return;
  const blob = new Blob([resultadosURLs.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `multimedia_extraida_${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}